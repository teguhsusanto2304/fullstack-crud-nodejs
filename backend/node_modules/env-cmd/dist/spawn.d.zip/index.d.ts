import { getEnvVars } from './get-env-vars';
export * from './types';
export * from './env-cmd';
export declare const GetEnvVars: typeof getEnvVars;
