import * as spawn from 'cross-spawn';
export { spawn };
